let projects = [];

function loadProjects() {
    const stored = localStorage.getItem('mirian_rating_full');
    if (stored) {
        projects = JSON.parse(stored);
    } else {
        projects = [
            { name: "Бирюзовая Катунь", location: "Алтай", price: 21000000, paybackYears: 7.5, occupancy: 75, operator: "Альта-Управление / 12%" },
            { name: "RIZALTA Resort", location: "Алтай", price: 13700000, paybackYears: 6.0, occupancy: 70, operator: "RIZALTA Hospitality / 15%" },
            { name: "Willa Monte 4*", location: "Архыз", price: 19400000, paybackYears: 8.5, occupancy: 82, operator: "Monte Management / 10%" },
            { name: "Alean Select Arkhyz", location: "Архыз", price: 21000000, paybackYears: 8.0, occupancy: 80, operator: "Alean Collection / 14%" },
            { name: "Горная резиденция", location: "Красная Поляна", price: 33500000, paybackYears: 10.0, occupancy: 80, operator: "Rosa Hospitality / 12%" },
            { name: "Студия Rosa Village", location: "Красная Поляна", price: 18900000, paybackYears: 9.5, occupancy: 78, operator: "Rosa Village Rent / 15%" },
            { name: "Cosmos Stay Hidden Yalta", location: "Крым", price: 2800000, paybackYears: 5.5, occupancy: 90, operator: "Cosmos MG / 18%" },
            { name: "Апарт-отель «Море»", location: "Крым", price: 26700000, paybackYears: 7.0, occupancy: 88, operator: "Crimea Invest Rent / 12%" }
        ];
    }
    renderRating();
}

function saveProjects() {
    localStorage.setItem('mirian_rating_full', JSON.stringify(projects));
}

function computeRating(proj, all) {
    let prices = all.map(p => p.price);
    let paybacks = all.map(p => p.paybackYears);
    let occs = all.map(p => p.occupancy);
    let minP = Math.min(...prices), maxP = Math.max(...prices);
    let minPay = Math.min(...paybacks), maxPay = Math.max(...paybacks);
    let minOcc = Math.min(...occs), maxOcc = Math.max(...occs);
    const normInv = (val, minV, maxV) => maxV === minV ? 1 : 1 - (val - minV) / (maxV - minV);
    const normDir = (val, minV, maxV) => maxV === minV ? 0.5 : (val - minV) / (maxV - minV);
    let score = normInv(proj.price, minP, maxP) * 0.3 + normInv(proj.paybackYears, minPay, maxPay) * 0.4 + normDir(proj.occupancy, minOcc, maxOcc) * 0.3;
    return Math.round(score * 100);
}

function renderRating() {
    let tbody = document.getElementById('ratingTableModalBody');
    if (!tbody) return;
    let withRating = projects.map(p => ({ ...p, rating: computeRating(p, projects) })).sort((a, b) => b.rating - a.rating);
    tbody.innerHTML = '';
    withRating.forEach((item, idx) => {
        let row = tbody.insertRow();
        row.insertCell(0).innerText = idx + 1;
        row.insertCell(1).innerHTML = `<strong>${escapeHtml(item.name)}</strong><br><span class="badge-location">${item.location}</span>`;
        row.insertCell(2).innerText = new Intl.NumberFormat('ru-RU').format(item.price) + ' ₽';
        row.insertCell(3).innerText = item.paybackYears + ' лет';
        row.insertCell(4).innerHTML = `<div>${item.occupancy}%</div><div style="background:#e8e8ed; border-radius:12px; height:5px; width:80px;"><div style="background:#007AFF; width:${item.occupancy}%; height:5px; border-radius:12px;"></div></div>`;
        row.insertCell(5).innerText = item.operator || '—';
        row.insertCell(6).innerHTML = `<span style="font-weight:600;">⭐ ${item.rating}</span>`;
        let delCell = row.insertCell(7);
        let delBtn = document.createElement('button');
        delBtn.innerHTML = '<i class="fas fa-trash-alt"></i>';
        delBtn.className = 'delete-btn';
        delBtn.onclick = () => {
            if (confirm('Удалить проект?')) {
                projects = projects.filter(p => p.name !== item.name || p.price !== item.price);
                saveProjects();
                renderRating();
            }
        };
        delCell.appendChild(delBtn);
    });
    if (projects.length === 0) tbody.innerHTML = '<tr><td colspan="8">Нет проектов. Добавьте первый.</td></tr>';
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function (m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

const modal = document.getElementById('ratingModal');
const openBtn = document.getElementById('openRatingModalBtn');
const closeBtn = document.getElementById('closeRatingModalBtn');

openBtn.onclick = () => {
    modal.style.display = 'flex';
    renderRating();
};
closeBtn.onclick = () => {
    modal.style.display = 'none';
};
window.onclick = (e) => {
    if (e.target === modal) modal.style.display = 'none';
};

const addBtn = document.getElementById('addProjectModalBtn');
const addForm = document.getElementById('addProjectForm');
addBtn.onclick = () => {
    addForm.style.display = 'block';
};
document.getElementById('cancelAddBtn').onclick = () => {
    addForm.style.display = 'none';
};
document.getElementById('confirmAddProjectBtn').onclick = () => {
    let name = document.getElementById('newProjName').value.trim();
    let location = document.getElementById('newProjLocation').value;
    let price = parseFloat(document.getElementById('newProjPrice').value);
    let payback = parseFloat(document.getElementById('newProjPayback').value);
    let occ = parseFloat(document.getElementById('newProjOccupancy').value);
    let operator = document.getElementById('newProjOperator').value.trim();
    if (!name || isNaN(price) || isNaN(payback) || isNaN(occ) || price <= 0 || payback <= 0 || occ < 0 || occ > 100) {
        alert('Заполните корректно все поля');
        return;
    }
    projects.push({ name, location, price, paybackYears: payback, occupancy: occ, operator: operator || '—' });
    saveProjects();
    renderRating();
    addForm.style.display = 'none';
    document.getElementById('newProjName').value = '';
    document.getElementById('newProjPrice').value = '';
    document.getElementById('newProjPayback').value = '';
    document.getElementById('newProjOccupancy').value = '';
    document.getElementById('newProjOperator').value = '';
};

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href === "#" || href === "") return;
        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

loadProjects();